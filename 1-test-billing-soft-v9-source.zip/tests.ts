import assert from 'node:assert/strict';import {fresh,totals,addPayment,stockMove,remove,restore,validate,technicianBalance,csv,suggestedBasis} from './engine';
let count=0;const test=(name:string,fn:()=>void)=>{fn();console.log('PASS',name);count++};
test('GST and partial payment',()=>{assert.deepEqual(totals(fresh().invoices[0]),{subtotal:3000,discount:0,tax:540,total:3540,paid:1000,due:2540})});
test('Discount before tax',()=>{const i=fresh().invoices[0];i.discount=500;assert.equal(totals(i).total,2950)});
test('Payment validation',()=>{const d=fresh();assert.throws(()=>addPayment(d,'i1',3000,'Cash'));assert.throws(()=>addPayment(d,'i1',-1,'Cash'));addPayment(d,'i1',2540,'UPI','t1');assert.equal(totals(d.invoices[0]).due,0);assert.equal(technicianBalance(d,'t1').held,2540)});
test('No negative stock',()=>{const d=fresh();assert.throws(()=>stockMove(d,'s1',-9,'test'));stockMove(d,'s1',-2,'job');assert.equal(d.stock[0].qty,6)});
test('Customer reference guard',()=>{assert.throws(()=>remove(fresh(),'customers','c1'))});
test('Trash restore roundtrip',()=>{const d=fresh();remove(d,'customers','c2');assert.equal(d.customers.length,1);restore(d,d.trash[0].id);assert.equal(d.customers.length,2)});
test('Backup validates and rejects broken refs',()=>{const d=fresh();assert(validate(JSON.parse(JSON.stringify(d))));d.invoices[0].customer='missing';assert(!validate(d))});
test('CSV formula injection blocked',()=>{assert(csv([['=HYPERLINK("bad")']]).includes("'=HYPERLINK"))});
console.log(count+' tests passed');

test('Mixed measured and flat items with GST and discount',()=>{const i={id:'smart',items:[{qty:10,rate:250,basis:'measurement'},{qty:7.5,rate:40,basis:'measurement'},{qty:99,rate:200,basis:'flat'}],gst:18,discount:100,payments:[]};assert.deepEqual(totals(i),{subtotal:3000,discount:100,tax:522,total:3422,paid:0,due:3422})});
test('Flat backup accepts ignored measurement and rejects invalid basis',()=>{const d=fresh();d.invoices[0].items=[{name:'PVC pipe',qty:0,rate:2000,basis:'flat'}];assert(validate(d));d.invoices[0].items[0].basis='wrong';assert(!validate(d))});
test('Legacy invoices retain quantity multiplication',()=>{const i=fresh().invoices[0];i.items=[{name:'PVC pipe',qty:10,rate:200}];assert.equal(totals(i).subtotal,2000)});
test('Payment limit follows mixed basis totals',()=>{const d=fresh();d.invoices[0].items=[{name:'PVC',qty:80,rate:2000,basis:'flat'}];d.invoices[0].gst=0;assert.throws(()=>addPayment(d,'i1',1001,'Cash'));addPayment(d,'i1',1000,'Cash');assert.equal(totals(d.invoices[0]).due,0)});

test('AC item name suggestions',()=>{for(const n of ['Copper pipe','coper pipe','wire','Electrical cable','insulation foam','Insulation tube','Aluminium pipe','aluminum pipe'])assert.equal(suggestedBasis(n),'measurement',n);for(const n of ['PVC pipe','Gas charging','Gas refill','Installation charge','Visiting charge','Service charge','Jet-pump cleaning','Deep cleaning','Repair charges'])assert.equal(suggestedBasis(n),'flat',n);for(const n of ['Stand','Bracket','Capacitor','PCB','Fan motor','Remote','Filter','Contactor','Unknown spare part'])assert.equal(suggestedBasis(n),'quantity',n)});
