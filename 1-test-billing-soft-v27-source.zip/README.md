# Billing Studio - test-billing-soft

Browser-local service billing app with violet/glass dark and light themes, dense spreadsheet tables and linked records. The public website is hosted using GitHub Pages from this repository.

## Run

Open the GitHub Pages website, or download `index.html` and serve it locally with `python -m http.server`. The built HTML includes its CSS and JavaScript and does not load remote scripts, fonts or APIs.

Editable source is in `1-test-billing-soft-v26-source.zip`. Extract it, then run:

```
npm ci
npm run dev
npm run build
npm test
```

The source uses React and TypeScript; the deployed output is static HTML, CSS and JavaScript.

## What works

- Customers, invoices, estimates, GST/discount calculations and partial payments.
- Per-line calculation: rate × quantity, rate × measurement (feet/metres), or flat rate-only charge. Copper pipe, wire/cable, insulation tube/foam and aluminium pipe suggest per-foot measurement. PVC, gas refill/charging, installation/service/visiting charges, jet-pump/deep cleaning and repair suggest flat charges. Stand/bracket, capacitor, PCB, motor, remote, filter and unknown parts use quantity. These are suggested billing defaults, not universal rules; review or override each line. Type an item name to see matching suggestions; use arrows then Enter/Tab or tap a suggestion to fill it. Free-text items are allowed. Suggestions apply to new lines until you choose a manual basis. The form includes Hindi-English How to use guidance and examples beside each calculation mode. Existing invoices keep their original quantity-based calculation until explicitly changed. Print, CSV, totals and tax use the same formula.
- AMC: 1/2-year contracts, whole-term included service count, planned dates/times, service types, completed/overdue visits, advance and receipt history, balance and AMC CSV. End date is the last covered day. Suggested schedules must be reviewed; no automatic invites/reminders. Existing legacy contracts keep dates and visits until edited. AMC receipts are separate from invoice receipts: log money once, not in both ledgers. Contract amount is the final whole-term agreed amount; no AMC tax calculation or payment collection.
- Daily jobs, stock movements, technician commission and cash handovers.
- Period reports, Excel-compatible CSV, browser Print/Save PDF, JSON backup/restore and deleted-record recovery.
- Full-width, full-viewport-height workspace with no centered outer frame.
- Dense column-and-row tables. Phones use the section picker and a per-row Details control. Wide viewports, including Chrome Desktop site on phones, show the sidebar by default. The Phone layout button can force the compact app layout.
- Dark/light themes and browser-local state. Only fictional demo records are shipped.

For normal phone sizing, turn Chrome's Desktop site setting off. That setting can zoom out the entire website independently of the app's layout.

## Limits

This is a functional preview, not production accounting software. Data stays in this browser and origin, not GitHub or a shared server. It does not sync between devices. Data from another hosting origin is not transferred automatically: download a JSON backup there, then restore it here if needed.

Keep backups. Browser storage can be cleared or fail. The workspace has a 2 MB data-size limit. Browser storage can still fail. JSON backups are not encrypted. There is no authentication, multi-user database, SMTP sending, real payment processing, XLSX export, or security guarantee. PDF output uses the browser print dialog.

The earlier `source-initial.zip` is an archive of the first version, not the current source.

## Fictional large demo

New browsers start with 150 synthetic customers, 15 invoices between ₹15,000 and ₹20,000 and 15 varied AMC contracts. Indian names/area labels are examples; Zero-prefixed dummy phone digits and sample addresses are not real contacts. Existing browser records are preserved. To replace an old workspace, use Settings > Load 150-customer demo, download a backup, then confirm replacement.

Invoice preview/print is a white document ordered shop, customer, technician, items and totals. Optional phone/email/GSTIN can be set in Settings. GST/GSTIN are hidden when the invoice GST rate is zero. A4 printing uses the browser Save PDF dialog; this is a billing preview, not a certified tax-invoice system.

## New local tools

- **Share via WhatsApp** opens the device share menu where supported: choose WhatsApp, review the customer/message and send. Unsupported browsers offer complete bill-text copy/download. No automatic send, public invoice link or PDF upload. Use Print / Save PDF to attach a PDF manually.
- **Payment reminders** lists pending invoice balances. Set an optional payment due date while editing a bill to see actual overdue days. Without one, it shows days unpaid. Estimates and AMC balances are excluded.
- **Monthly collections** shows the last six calendar months using receipt dates, split into invoice and AMC receipts. This is received revenue, not profit. Top customers uses invoice-date filters and billed invoice totals, excluding estimates and AMC.
- **Service rate card** saves rate, calculation type and unit. Typing/selecting an exact saved item name fills those values during billing. Manual overrides remain possible. Changing or deleting a rate never changes an existing bill.
- **Visit reminders** lists every incomplete overdue AMC visit and visits within the next30 days, with a manage action. Alerts are in-app, not background push notifications.

Everything stays browser-local; only a deliberate device sharing action hands the chosen bill text to another app. No paid APIs, card or subscription is needed. Rates and due dates are included in JSON backups. Older valid backups without these fields still load.

## Analytics export

Reports offers Export Excel with charts: Summary is sheet1, native editable Charts is sheet2, then11 typed, styled data sheets plus Chart_data and Data_dictionary. Includes frozen headers, filters, striped Excel tables, numeric amounts, real Excel dates and Text IDs/phones. Four charts:12-month receipt trend, top customer billing, receipt-mode comparison and paid/due stacked balance. No server, paid library, API, subscription or card. Charts and values are export snapshots; re-export to refresh.

Date/search filters apply by each dataset's own date field. AMC contracts, customer, team and inventory sheets are current/all-time snapshots with search applied. Monthly chart covers12 months ending at the selected To date (or today); receipts after today are excluded from that chart. Top customers and paid/due use selected invoice dates, excluding estimates. Receipt tables include actual selected invoice and AMC receipts. No profit claim or certified tax report.

Clean CSV datasets remain available: stable IDs, ISO dates, UTF-8, plain numeric INR values and separate currency field. CSV cannot store styling or cell types: import ID/phone columns as Text in Excel. XLSX handles types. Formula-looking source text is stored as text; the workbook contains no macros or external connections. Blank means not applicable/unknown.

## Direct section CSVs

Every section has its own Export CSV button under its heading. Uses the same clean analytics columns. Visible search/date/payment filters are applied where offered; no hidden invoice date filter affects customer/stock/team/AMC sections. Overview exports the metric snapshot, Settings exports business identity/settings and Deleted Items exports the deleted record index. Use JSON backup for a full recoverable workspace. Payment and visit reminder exports include only the rows matching their reminder criteria.

## Formatted section exports (v27)

Every section now has a primary **Export Excel** (.xlsx) button and a secondary **Export CSV** button. Excel preserves styled headers, striped tables, header sort/filter dropdowns, frozen first row, sensible widths, wrapped text/row heights, numeric INR amounts and real dates. IDs/phones stay Text. First sheet is section data; Export_info records scope/current filters and Data_dictionary explains types. Empty results retain headers and filters. This is a static browser-local export, not live sync. CSV cannot preserve visual formatting or filter controls. Open .xlsx in Excel/LibreOffice or an Excel-compatible spreadsheet app; basic phone previewers may not offer filter controls. Reports still offers the full workbook with Charts on the second sheet.
